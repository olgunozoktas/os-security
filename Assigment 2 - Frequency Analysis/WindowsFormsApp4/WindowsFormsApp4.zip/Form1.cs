﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public List<LibraryKey> cipherText = new List<LibraryKey>();
        public List<String> usedKey = new List<String>();
        public List<LibraryKey> keys = new List<LibraryKey>();
        public bool f;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            keys.Add(new LibraryKey("a", "8.12"));
            keys.Add(new LibraryKey("b", "1.49"));
            keys.Add(new LibraryKey("c", "2.71"));
            keys.Add(new LibraryKey("d", "4.32"));
            keys.Add(new LibraryKey("e", "12.02"));
            keys.Add(new LibraryKey("f", "2.30"));
            keys.Add(new LibraryKey("g", "2.03"));
            keys.Add(new LibraryKey("h", "5.92"));
            keys.Add(new LibraryKey("i", "7.31"));
            keys.Add(new LibraryKey("j", "0.10"));
            keys.Add(new LibraryKey("k", "0.69"));
            keys.Add(new LibraryKey("l", "3.98"));
            keys.Add(new LibraryKey("m", "2.61"));
            keys.Add(new LibraryKey("n", "6.95"));
            keys.Add(new LibraryKey("o", "7.68"));
            keys.Add(new LibraryKey("p", "1.82"));
            keys.Add(new LibraryKey("q", "0.11"));
            keys.Add(new LibraryKey("r", "6.02"));
            keys.Add(new LibraryKey("s", "6.28"));
            keys.Add(new LibraryKey("t", "9.10"));
            keys.Add(new LibraryKey("u", "2.88"));
            keys.Add(new LibraryKey("v", "1.11"));
            keys.Add(new LibraryKey("w", "2.09"));
            keys.Add(new LibraryKey("x", "0.17"));
            keys.Add(new LibraryKey("y", "2.11"));
            keys.Add(new LibraryKey("z", "0.07"));

            //MessageBox.Show("Size of list is: " + keys.Count.ToString());
            //Bubble Sort to arrange the list
            for (int i = 0; i < keys.Count; i++)
            {
                for (int j = 0; j < keys.Count; j++)
                {
                    if(float.Parse(keys[j].frequency) < float.Parse(keys[i].frequency))
                    {
                        LibraryKey temp = keys[j];
                        keys[j] = keys[i];
                        keys[i] = temp;
                    }
                }
            }

            for(int i=0; i<keys.Count; i++)
            {
                /*this.chart1.Series["Letter"].Points.AddXY(keys[i].keyword, float.Parse(keys[i].frequency));*/
                dataGridView1.Columns.Add(keys[i].keyword, keys[i].keyword);
                dataGridView1.Rows[0].Cells[i].Value = keys[i].frequency;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            //dataGridView2.Columns.Clear();
            //dataGridView2.Rows.Clear();

            if (f)
            {
                MessageBox.Show("You already gave cipherText before");
                return;
            }

            if(textBox1.Text == "")
            {
                MessageBox.Show("You have to enter chiper text to continue!!!");
                return;
            }

            String value = textBox1.Text;
            bool exist = false;
            int count;
            for(int i=0; i<value.Length; i++)
            {
                count = 0;
                for(int j=0; j<value.Length; j++)
                {

                    if(value[i].Equals("'") || value[i].Equals(",") || value[i].Equals(".") || value[i].Equals('"') ||
                        value[i].Equals(";") || value[i].Equals("  ") || value[i].Equals(' ') || value[i].Equals("|") ||
                        value[i].Equals(',') || value[i].Equals(" '"))
                    {
                        exist = true; //to make sure that statement is true
                        break;
                    }

                    exist = checkIfKeyExists(value[i].ToString());
                    //MessageBox.Show("Exist: " + exist);
                    if (exist == true)
                    {
                        //MessageBox.Show(value[i].ToString() + " is exist in the library");
                        break;
                    }
                    else
                    {
                        if(value[i].ToString() == value[j].ToString())
                        {
                            count++;
                        }
                    }
                }
                if (!exist)
                {
                    usedKey.Add(value[i].ToString());
                    cipherText.Add(new LibraryKey(value[i].ToString(), count.ToString()));
                }
                exist = false;
                //MessageBox.Show(value[i].ToString() + " is counted as " + count);
                //break;
            }

            bool existInCipherText;
            for(int i=0; i<keys.Count; i++)
            {
                existInCipherText = false;
                for(int j=0; j<cipherText.Count; j++) { 
                    
                    if(cipherText[j].keyword == keys[i].keyword.ToUpper() || cipherText[j].keyword == keys[i].keyword.ToLower())
                    {
                        existInCipherText = true;
                        break;
                    }
                }

                if (!existInCipherText)
                {
                    cipherText.Add(new LibraryKey(keys[i].keyword.ToUpper(), "0"));
                }
            }


            //Bubble Sort to order them desc order
            for (int i = 0; i < cipherText.Count; i++)
            {
                for (int j = 0; j < cipherText.Count; j++)
                {
                    if (float.Parse(cipherText[j].frequency) < float.Parse(cipherText[i].frequency))
                    {
                        LibraryKey temp = cipherText[j];
                        cipherText[j] = cipherText[i];
                        cipherText[i] = temp;
                    }
                }
            }

            for (int i = 0; i < cipherText.Count; i++)
            {
                dataGridView2.Columns.Add(cipherText[i].keyword, cipherText[i].keyword);
                dataGridView2.Rows[0].Cells[i].Value = cipherText[i].frequency;
            }

            f = true;
            fillComboBoxes();
            richTextBox1.Text = textBox1.Text;

        }


        public bool checkIfKeyExists(String value)
        {
            for(int i=0; i<usedKey.Count; i++)
            {
                if(usedKey[i] == value.ToUpper() || usedKey[i] == value.ToLower()) {
                    return true;
                }
            }

            return false;
        }

        public void fillComboBoxes()
        {
            for(int i=0; i<keys.Count; i++)
            {
                comboBox2.Items.Add(keys[i].keyword);
                comboBox1.Items.Add(cipherText[i].keyword);
            }

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            String replaceWith = comboBox2.SelectedItem.ToString();
            MessageBox.Show("Replace With: " + replaceWith);
            String value = comboBox1.SelectedItem.ToString();
            MessageBox.Show("Value : " + value);
            String cipher = richTextBox1.Text;
            StringBuilder b = new StringBuilder(cipher);
            for(int i=0; i<cipher.Length; i++)
            {
                if(cipher[i].Equals(value))
                {
                    char a = replaceWith[0];
                    cipher.Replace(cipher[i], a);
                }
            }

            richTextBox1.Text = cipher;


        }

        private void tableLayoutPanel7_Paint(object sender, PaintEventArgs e)
        {

        }
    }

    public class LibraryKey
    {
        public bool used { get; set; }
        public String keyword { get; set; }
        public String frequency { get; set; }

        public LibraryKey(String keyword, String frequency)
        {
            this.keyword = keyword;
            this.frequency = frequency;
            this.used = false;
        }
    }
}


